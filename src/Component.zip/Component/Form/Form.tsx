
import React from "react";
import "./FormStyle.scss";

export interface FormData {
  name: string;
  placeholder: string;
  label: string;
  fullwidth: boolean;
  required: boolean;
  validation?: {
    minLength?: number;
    maxLength?: number;
    pattern?: string;
   
  };

  htmlElement: string;
}

interface FormProps {
  data: {
    button: string;
    fields: FormData[];
  };
}

const Form: React.FC<FormProps> = ({ data }) => {
  return (
    <div className="form-container">
      <form>
        {data.fields.map((field, index) => {

          return (
            <div key={index} className="form-field">
              {field.htmlElement === "textarea" ? (
                <textarea
                  className="input-textarea"
                  name={field.name}
                  placeholder={field.placeholder}
                  required={field.required}
                  minLength={field.validation?.minLength}
                  maxLength={field.validation?.maxLength}
                  
                ></textarea>
              ) : (
                <input
                  className="input-text"
                  type={field.htmlElement}
                  name={field.name}
                  placeholder={field.placeholder}
                  required={field.required}
                  maxLength={field.validation?.maxLength}
                  pattern={field.validation?.pattern}
                  
                />
              )}
            </div>
          );
        })}
        <button type="submit" className="submit-button">
          {data.button}
        </button>
      </form>
    </div>
  );
};

export default Form;